<?php

$conexao = mysqli_connect("localhost", "root", "", "cadastrov");

$arquivo = fopen(cadveiculo.txt, "w");

$seleciona_dados = mysqli_query($conexao, "select * from tbl_veiculos");
while ($dados = mysqli_fetch_array($seleciona_dados)) {

	$proprietario = $dados['proprietario'];
	$veiculo = $dados['veiculo'];

	//echo "<br>".$dados['proprietario']." - ".$dados['veiculo'];
	fwrite($arquivo, $proprietario."-".$veiculo);
}

foreach (file(cadveiculo.txt) as $valor) {
	
	echo "<br>".$valor;
}



?> 


