
<?php

// INICIA LIGAÇÃO À BASE DE DADOS
$con=mysqli_connect("localhosT","root","","cadastrov");

// VERIFICA A LIGAÇÃO NÃO TEM ERROS
if (mysqli_connect_errno())
{
    // CASO TENHA ERROS MOSTRA O ERRO DE LIGAÇÃO À BASE DE DADOS
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

// CASO TUDO ESTEJA OK INSERE DADOS NA BASE DE DADOS
$sql="INSERT INTO tbl_veiculos (veiculo, marca, modelo, proprietario) VALUES ('$_POST[veiculo]','$_POST[marca]','$_POST[modelo]', '$_POST[proprietario]')";


// CASO ESTEJA TUDO OK ADICIONA OS DADOS, SENÃO MOSTRA O ERRO
if (!mysqli_query($con,$sql))
{
    die('Error: ' . mysqli_error($con));
}

// MOSTRA A MENSAGEM DE SUCESSO

	

mysqli_close($con);

echo 
	"<script>
	alert('Cadastrado com Sucesso!'); location= './index.html';
	</script>";﻿﻿

?>